zip -r zpplib-release-v0.1.zip .  \
 -x "bazel-zpplib/*"  -x "bazel-bin/*" -x "bazel-out/*" -x ".git/*" \
 -x "bazel-testlogs/*"

