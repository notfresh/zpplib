#include <iostream>
#include "math.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    std::cout << greater_(10, 8) << std::endl;
    return 0;
}
